 export const teamColors: Record<string, string>={
    core:"text-[#e7b39f]", tech:"text-[#cfa7b8]", events:"text-[#bc9ecd]", design:"text-[#a594e4]", marketing:"text-[#8e89fd]" };

 
