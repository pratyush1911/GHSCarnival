import NavBar from '../components/NavBar'

export default function GuidelinesPage() {
  return (
    <>
      <div data-page="guidelines" />
      <NavBar />
    </>
  )
}
